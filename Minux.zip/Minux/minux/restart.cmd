color
call term.cmd