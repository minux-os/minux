@echo off
chcp 65001 >nul
echo PUM - Ping URL Method
echo PFPUM - Packages for Ping URL Method
goto rget
:rget
cls
set /p pum="Enter PUM: "
echo PUM - %pum%
echo PFPUM - %pfpum%
cls
echo PUM - %pum%
echo PFPUM - %pfpum%
set /p pfpum="Enter PFPUM: "
echo PUM - %pum%
echo PFPUM - %pfpum%
cls
echo echo PUM - %pum%
echo PFPUM - %pfpum%
echo 🚀 I`m sending network packages   
ping %pum% -n %pfpum%
echo Packages sent: %pfpum%
REM ForeverLog Script
echo Welcome To Module ForeverLog
timeout 5 >nul
echo -- Creating Folders and file --
mkdir foreverlog
cd foreverlog
echo -- ForeverLog --
echo -- Changes --
echo Site - %pum%
echo Packages - %pfpum%
echo Site - %pum% > fl.log
echo Packages - %pfpum% >> fl.log 
pause
set pum=
set pfpum=
exit