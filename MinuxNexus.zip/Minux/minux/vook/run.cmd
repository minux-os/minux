echo Vook is launched!
@echo off
chcp 65001 >nul
echo Welcome to vook!
mkdir root
timeout /t 5
:vookstart
cls
title Vook
echo Welcome To Vook!
echo Current path: %cd%
echo Script path: %~dp0
goto vook
:vook
set /p command="vook@vook:~$ "
if "%command%"=="cmd" cmd && goto vook
if "%command%"=="ls" dir && goto vook
if "%command%"=="pwd" goto pwd
if "%command%"=="cat" goto cat
if "%command%"=="mkdir" goto mkdir
if "%command%"=="touch" goto touch
if "%command%"=="rm" goto rm
if "%command%"=="clear" cls
if "%command%"=="echo > /dev/null" goto echonull
if "%command%"=="echo" goto echo
if "%command%"=="sudo -i" goto sudo
if "%command%"=="whoami" goto whoami

:pwd
echo %CD%
goto vook
:cat
set /p filename="File name: "
if exist "%filename%" (
    type "%filename%"
) else (
    echo 1
)
goto vook


:mkdir
set /p folder="Folder name: "
mkdir "%folder%" 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto vook

:touch
set /p touch="File name: "
echo. > "%touch%" 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto vook

:rm
set /p rm="File name: "
del "%rm%" 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto vook

:cat
set /p filename="File name: "
if exist "%filename%" (
    type "%filename%"
    echo.
    echo 0
) else (
    echo 1
)
goto vook

:echonull
set /p textnull="Text: "
echo %textnull% >nul 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto vook
:echo
set /p textecho="Text: "
echo %textecho%
goto vook
:sudo
set /p rootpass="root login: "
if "%rootpass%"=="root" (
    if not exist root mkdir root
    cd root
    goto rootvook
) else (
    echo Password incorrect!
    goto vook
)
:rootvook
set /p sudo="root@vook:~$ "
if "%sudo%"=="cmd" cmd
if "%sudo%"=="ls" dir && goto sudovook
if "%sudo%"=="pwd" goto pwd && goto sudovook
if "%sudo%"=="cat" goto rootcat
if "%sudo%"=="mkdir" goto rootmkdir
if "%sudo%"=="touch" goto roottouch
if "%sudo%"=="rm" goto rm
if "%sudo%"=="clear" cls && goto rootvook
if "%sudo%"=="echo > /dev/null" goto rootechonull
if "%sudo%"=="echo" goto rootecho
if "%sudo%"=="whoami" goto rootwhoami
if "%sudo%"=="logout" cd .. && goto vook



:rootwhoami
echo root
goto sudovook


:whoami
echo vook
goto vook
:rootcat
set /p filename="File name: "
if exist "%filename%" (
    type "%filename%"
    echo.
    echo 0
) else (
    echo 1
)
goto rootvook
:rootmkdir
set /p folder="Folder name: "
mkdir "%folder%" 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto rootvook
:roottouch
set /p touch="File name: "
echo. > "%touch%" 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto rootvook
:rootrm
set /p rm="File name: "
del "%rm%" 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto rootvook
:rootechonull
set /p textnull="Text: "
echo %textnull% >nul 2>nul
if %errorlevel% equ 0 (
    echo 0
) else (
    echo 1
)
goto rootvook
:rootecho
set /p textecho="Text: "
echo %textecho%
goto rootvook