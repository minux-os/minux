@echo off
title minux\moon\moon.ma
echo Moon
echo Kostya Aidin (c) 2026 All rights reserved
:moon
set /p command="administrator@moon:~$ "
if "%command%"=="ping" goto ping
if "%command%"=="paint" mspaint
if "%command%"=="diskpart" powershell -Command Start-Process "diskpart" -Verb RunAs && goto moon
if "%command%"=="moon -S from: image" goto image
if "%command%"=="exit" exit
:ping
set host=google.com
set p=5
ping %host% -n %p%
goto moon
:image
powershell -Command Start-Process "moonimage.cmd" -Verb RunAs
pause
goto moon