@echo off
powershell -Command Start-Process ".\moonadmin.cmd" -Verb RunAs