@echo off
echo _
timeout /t 1 >nul
cls
echo.
timeout /t 1 >nul
cls
echo _
timeout /t 1 >nul
cls
echo.
timeout /t 1 >nul
cls
echo POST successful
timeout /t 1 >nul
cls
timeout /t 1 >nul
cls
echo WorldBIOS
echo Booting from CD-ROM.
timeout /t 1 >nul
cls
echo WorldBIOS
echo Booting from CD-ROM..
timeout /t 1 >nul
cls
echo WorldBIOS
echo Booting from CD-ROM...
timeout /t 1 >nul
cls
echo WorldBIOS
echo Booting from CD-ROM....
timeout /t 1 >nul
cls
echo WorldBIOS
echo Booting from CD-ROM.....
timeout /t 1 >nul
cls
echo WorldBIOS
echo Booting from CD-ROM.....
echo Moon
echo Please wait...
timeout /t 5 >nul
cls
title moon.ma
echo Moon
echo Kostya Aidin (c) 2026 All rights reserved
:moon
set /p command="administrator@moon:~$ "
if "%command%"=="ping" goto ping
if "%command%"=="paint" mspaint && goto moon
if "%command%"=="diskpart" powershell -Command Start-Process "diskpart" -Verb RunAs && goto moon
if "%command%"=="moon -S from: image" goto image
if "%command%"=="exit" exit
:ping
set host=google.com
set p=5
ping %host% -n %p%
goto moon
:image
moonimage.cmd