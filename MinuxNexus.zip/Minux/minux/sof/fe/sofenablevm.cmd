@echo off
title SOF
echo System SOF
echo Version: 1.0
timeout /t 3 >nul
cd ..
cd ..
cd ..
mkdir vms 2>nul
set /p domain="Enter domain: "
mkdir "vms\%domain%" 2>nul
copy term.cmd "vms\%domain%\term.cmd"
echo @echo off >> "vms\%domain%\del.cmd"
echo echo ===MinuxVMs=== >> vms\%domain%\del.cmd
echo timeout /t 3 >nul >> vms\%domain%\del.cmd
echo cd .. >> vms\%domain%\del.cmd
echo set /p deldomain="Enter domain for vm: " >> vms\%domain%\del.cmd
echo echo Success! >> %domain%\del.cmd
echo rmdir %deldomain% >> vms\%domain%\del.cmd
echo pause ^>nul >> "vms\%domain%\del.cmd"
if exist "vms\%domain%\term.cmd" (
    title MinuxVMs - Success
    echo Success!
    echo Please wait...
    timeout /t 3 >nul
    title MinuxVMs - %domain%
    call "vms\%domain%\term.cmd"
) else (
    echo Failed to copy term.cmd
)
pause