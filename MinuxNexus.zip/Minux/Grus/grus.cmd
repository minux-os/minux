@echo off
chcp 65001 >nul
title Grus
:grus
echo [1] Build notepad
set /p gros="gros@gros:~$ "
if "%gros%"=="1" goto build_notepad
:build_notepad
mkdir dist
cd dist
set /p bn="Enter name: "
mkdir %bn%
cd %bn%
echo REM Powered by Grus >> builded.cmd
cd ..
cd ..
echo OK >> notepad-33ed-ex38-po74
echo OK >> notepad-33ed-ex38-po21
timeout /t 5 >nul
del notepad-33ed-ex38-po74
del notepad-33ed-ex38-po21
cd dist/%n%
echo @echo off >> builded.cmd
echo title Notepad >> builded.cmd
echo chcp 65001 >nul >> builded.cmd
echo echo ===Powered by Grus=== >> builded.cmd
echo timeout /t 5 >nul >> builded.cmd
echo notepad >> builded.cmd
echo Success!
echo Builded
cd ..
cd ..
goto grus