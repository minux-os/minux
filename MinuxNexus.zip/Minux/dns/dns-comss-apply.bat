@echo off
chcp 65001 > nul
title DNS Comss Apply (Ultimate Edition)

:: Проверка прав администратора
net session >nul 2>&1
if %errorLevel% neq 0 (
    echo ❌ ОШИБКА: Запустите от имени АДМИНИСТРАТОРА!
    pause
    exit /b
)

:menu
cls
echo ============================================
echo      DNS COMSS APPLY - ВЫБЕРИ СЕРВЕР
echo ============================================
echo [1] 212.109.195.93 (Основной)
echo [2] 83.220.169.155 (Резервный 1)
echo [3] 195.133.25.16  (Резервный 2)
echo [4] Вернуть автоматический DNS (DHCP)
echo [5] Выход
echo ============================================
set /p choice="Введите номер (1-5): "

if "%choice%"=="1" set "dns=212.109.195.93" & goto apply
if "%choice%"=="2" set "dns=83.220.169.155" & goto apply
if "%choice%"=="3" set "dns=195.133.25.16"  & goto apply
if "%choice%"=="4" goto reset
if "%choice%"=="5" exit /b
goto menu

:apply
echo.
echo ⏳ Применяю DNS %dns% ко всем активным адаптерам...
:: Цикл проходит по всем интерфейсам, которые подключены, и ставит им DNS
for /f "tokens=1,2,3*" %%a in ('netsh interface ipv4 show interfaces ^| findstr "connected"') do (
    echo 🚀 Настройка адаптера ID: %%a...
    netsh interface ipv4 set dns name=%%a static %dns% Primary >nul 2>&1
)
goto end

:reset
echo.
echo ⏳ Возврат к автоматическим настройкам (DHCP)...
for /f "tokens=1,2,3*" %%a in ('netsh interface ipv4 show interfaces ^| findstr "connected"') do (
    echo 🚀 Сброс адаптера ID: %%a...
    netsh interface ipv4 set dns name=%%a source=dhcp >nul 2>&1
)
goto end

:end
echo ✅ Почти готово! Сбрасываю кэш...
ipconfig /flushdns > nul
echo ✨ Настройки применены! Попробуй зайти на любой сайт.
pause
goto menu