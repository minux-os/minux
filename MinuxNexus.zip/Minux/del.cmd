echo ===MinuxVMs=== 
timeout /t 3 
cd .. 
set /p deldomain="Enter domain for vm: " 
Success! 
rmdir  
rmdir  
