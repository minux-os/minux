@echo off
chcp 65001 >nul
cls
color 0B
echo.
echo  --- Minux Security Hub --------------------------
echo  User: %USERNAME%    System: Minux NEXT (2026)
echo  -------------------------------------------------
echo  1. [SCAN]   Scan System for errors
echo  2. [FILES]  Secret Folders Manager
echo  3. [NET]    Network Ports Check
echo  4. [GEN]    Password Generator
echo  0. [BACK]   Return to Main Menu
echo  -------------------------------------------------
echo.
set /p secure_cmd="minux@secure:~$ "

if "%secure_cmd%"=="1" goto sys_scan
if "%secure_cmd%"=="2" goto file_manager
if "%secure_cmd%"=="3" goto net_check
if "%secure_cmd%"=="4" goto pass_gen
if "%secure_cmd%"=="0" goto minux
goto security_menu

:sys_scan
cls
echo [MINUX] Initializing Scan...
timeout /t 1 >nul
for /L %%i in (1,10,100) do (
    cls
    echo Scanning Minux Kernel: %%i%%
    ping localhost -n 1 >nul
)
echo.
echo [OK] All sectors are clean!
pause
goto security_menu

:file_manager
cls
echo.
echo  File Manager
echo 1. Create secret folder
echo 2. Show files list
echo 0. Back
set /p f_cmd="files@minux:~$ "
if "%f_cmd%"=="1" (
    set /p folder_name="Folder name: "
    mkdir "%folder_name%"
    echo %date% %time% > "%folder_name%\created.log"
    echo Done!
    pause
)
if "%f_cmd%"=="2" (
    dir /w
    pause
)
goto security_menu

:net_check
cls
echo [NETWORK REPORT]
echo Connection: OK
echo.
netstat -n | findstr "ESTABLISHED"
echo.
pause
goto security_menu

:pass_gen
cls
echo [PASSWORD GENERATOR]
echo Your new Minux pass:
echo MNX-%RANDOM%-%RANDOM%
echo.
pause
goto security_menu