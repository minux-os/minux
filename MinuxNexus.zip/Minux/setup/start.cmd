@echo off
echo Starting...
powershell -Command Start-Process "files\setup.cmd" -Verb RunAs
pause