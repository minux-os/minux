@echo off
title MINUX | setup
powershell -Command Start-Process "bin\operations.cmd" -Verb RunAs