@echo off 
echo ===MinuxVMs=== 
timeout /t 3 
cd .. 
set /p deldomain="Enter domain for vm: " 
echo Success! 
rmdir  
pause >nul 
