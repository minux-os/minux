@echo off
:: Переход в папку, где лежит сам батник
cd /d "%~dp0"

title Minux Setup
echo Please press any key to start downloading...
pause >nul

echo Downloading MINUX...
curl -f -L -O https://github.com/minux-os/Releases/raw/refs/heads/main/MinuxNexus.zip

if %errorlevel% equ 0 (
    echo.
    echo Download complete!
    title Minux ^| Setup completed
) else (
    echo.
    echo [ERROR] Download failed! Check your connection or URL.
    title Minux ^| Error
)

echo.
echo Press any key to unpack
pause >nul
tar -xf MinuxNexus.zip
del MinuxNexus.zip
echo Press any key to open
pause >nul
    cd Minux
    powershell -Command ./term.cmd