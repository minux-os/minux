run command:
powershell -Command ./operations.cmd