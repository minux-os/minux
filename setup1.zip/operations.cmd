@echo off
timeout /t 1 >nul
echo Changes have been applied
timeout /t 1 >nul
echo Changes have been applied
ping -n 1 localhost >nul
echo Changes have been applied
echo Changes have been applied
echo Changes have been applied
powershell -Command ./setup.cmd